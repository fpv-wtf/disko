/*
 * disko_version.h
 *
 *  Created on: Jan 16, 2010
 *      Author: sxs
 */

#ifndef DISKO_VERSION_H_
#define DISKO_VERSION_H_

#define DISKO_VERSION_STR "1.7.0"
#define DISKO_VERSION 170
#define DISKO_MAJOR_VERSION 1
#define DISKO_MINOR_VERSION 7
#define DISKO_MICRO_VERSION 0


#endif /* DISKO_VERSION_H_ */

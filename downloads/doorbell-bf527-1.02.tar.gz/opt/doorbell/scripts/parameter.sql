DELETE FROM PluginProperties WHERE PluginID = -1;
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('OpenDoorCmd','/usr/bin/opendoor.sh','string',0,0,NULL,'',-2);
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('LodgerList','./etc/user.txt','string',0,0,NULL,'',-2);
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('AdminMailTo','changeme','string',0,0,NULL,'',-2);
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('AdminMailFrom','changeme','string',0,0,NULL,'',-2);
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('Mailserver','changeme','string',0,0,NULL,'',-2);
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('MailserverUsername','changeme','string',0,0,NULL,'',-2);
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('MailserverPwd','changeme','string',0,0,NULL,'',-2);
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('Longitude','13.4','string',0,0,NULL,'',-2);
INSERT INTO PluginProperties(Parameter, Value, TYPE, MIN, MAX, VALLIST,  SEPARATOR,PluginID )
VALUES('Latitude','52.5167','string',0,0,NULL,'',-2);


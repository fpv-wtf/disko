BEGIN TRANSACTION;
CREATE TABLE Plugins 
(
	ID INTEGER NOT NULL PRIMARY KEY,
	PluginName VARCHAR NOT NULL UNIQUE,
	PluginTitle VARCHAR NOT NULL,
	PluginDescription VARCHAR,
	Filename VARCHAR NOT NULL,
	PluginPath VARCHAR NOT NULL,
	Active CHAR(1) NOT NULL,
	Icon VARCHAR,
	SelectedIcon VARCHAR,
	SmallIcon VARCHAR,
	SmallSelectedIcon VARCHAR,
	OrderPos INTEGER,
	PluginTypeID INTEGER CONSTRAINT FK_PluginTypeID REFERENCES PluginTypes(ID),
	CategoryID INTEGER CONSTRAINT FK_CategoryID REFERENCES Category(ID)
);
INSERT INTO "Plugins" VALUES(-2,'SYSTEM','SYSTEM','SYSTEM','SYSTEM','SYSTEM','N','SYSTEM','SYSTEM','SYSTEM','SYSTEM',-1,5,-1);



CREATE TABLE Category
(
	ID INTEGER NOT NULL PRIMARY KEY,
	CategoryName VARCHAR NOT NULL UNIQUE
);
CREATE TABLE PluginProperties 
(
	Parameter VARCHAR NOT NULL,
	Value VARCHAR NOT NULL,
	TYPE VARCHAR CHECK (TYPE IN ('string','integer','float','set','enum')) DEFAULT 'string',
	MAX INTEGER,
	MIN INTEGER,
	VALLIST VARCHAR,
	SEPARATOR CHAR(1),
	PluginID INTEGER,
	PRIMARY KEY (Parameter, Value, PluginID)
);
CREATE TABLE PluginTypes 
(
	ID INTEGER NOT NULL PRIMARY KEY,
	PluginTypeName VARCHAR UNIQUE
);
INSERT INTO "PluginTypes" VALUES(1,'OSD_PLUGIN');
INSERT INTO "PluginTypes" VALUES(2,'BACKEND_PLUGIN');
INSERT INTO "PluginTypes" VALUES(3,'IMPORT_PLUGIN');
INSERT INTO "PluginTypes" VALUES(4,'CENTRAL_PLUGIN');
INSERT INTO "PluginTypes" VALUES(5,'SYSTEM');


CREATE TABLE ImportProperties 
(
	ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	PluginID INTEGER NOT NULL UNIQUE,
	onStartUp CHAR(1),
	Time INTEGER,
	Interval INTEGER
);
DELETE FROM sqlite_sequence;
CREATE TABLE ImportSource 
(
	ID INTEGER NOT NULL PRIMARY KEY ASC AUTOINCREMENT,
	PluginID INTEGER NOT NULL,
	Name VARCHAR,
	Source VARCHAR,
	LifeTime INTEGER,

	UNIQUE (PluginID, Source)
);
CREATE TRIGGER fki_plugins_plugintypes_id BEFORE INSERT ON Plugins
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT ID FROM PluginTypes WHERE ID = NEW.PluginTypeID) IS NULL)
     THEN RAISE(ABORT, 'insert on table "Plugins" violates foreign key. [PluginType doesnt exist]')
  END;
END;
CREATE TRIGGER fku_plugins_plugintypes_id BEFORE UPDATE ON Plugins
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT ID FROM PluginTypes WHERE ID = NEW.PluginTypeID) IS NULL)
     THEN RAISE(ABORT, 'update on table "Plugins" violates foreign key. [PluginType doesnt exist]')
  END;
END;
CREATE TRIGGER fkd_plugins_plugintypes_id BEFORE DELETE ON Plugintypes
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT PluginTypeID FROM Plugins WHERE PluginTypeID = ID))
     THEN RAISE(ABORT, 'delete of PluginType violates foreign key. [PluginType used by Plugins]')
  END;
END;
CREATE TRIGGER fkd_plugins BEFORE DELETE ON Plugins
FOR EACH ROW BEGIN 
    DELETE FROM PluginProperties WHERE PluginID = OLD.ID;
    DELETE FROM ImportProperties WHERE PluginID = OLD.ID;
END;
CREATE TRIGGER fki_pluginproperties_plugins_id BEFORE INSERT ON PluginProperties
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT ID FROM Plugins WHERE ID = NEW.PluginID) IS NULL)
     THEN RAISE(ABORT, 'insert on table "PluginProperties" violates foreign key. [PluginID doesnt exist]')
  END;
END;
CREATE TRIGGER fku_pluginproperties_plugins_id BEFORE UPDATE ON PluginProperties
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT ID FROM Plugins WHERE ID = NEW.PluginID) IS NULL)
     THEN RAISE(ABORT, 'update on table "PluginProperties" violates foreign key. [PluginID doesnt exist]')
  END;
END;
CREATE TRIGGER fki_importproperties_plugins_id BEFORE INSERT ON ImportProperties
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT ID FROM Plugins WHERE ID = NEW.PluginID) IS NULL)
     THEN RAISE(ABORT, 'insert on table "ImportProperties" violates foreign key. [PluginID doesnt exist]')
  END;
END;
CREATE TRIGGER fku_importproperties_plugins_id BEFORE UPDATE ON ImportProperties
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT ID FROM Plugins WHERE ID = NEW.PluginID) IS NULL)
     THEN RAISE(ABORT, 'update on table "ImportProperties" violates foreign key. [PluginID doesnt exist]')
  END;
END;
CREATE TRIGGER fkd_importproperties BEFORE DELETE ON ImportProperties
FOR EACH ROW BEGIN 
    DELETE FROM ImportSource WHERE PluginID = OLD.PluginID;
END;
CREATE TRIGGER fki_importsource_importproperties_pluginid BEFORE INSERT ON ImportSource
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT PluginID FROM ImportProperties WHERE PluginID = NEW.PluginID) IS NULL)
     THEN RAISE(ABORT, 'insert on table "ImportSource" violates foreign key. [PluginID in ImportProperties doesnt exist]')
  END;
END;
CREATE TRIGGER fku_importsource_importproperties_pluginid BEFORE UPDATE ON ImportSource
FOR EACH ROW BEGIN 
  SELECT CASE
     WHEN ((SELECT PluginID FROM ImportProperties WHERE PluginID = NEW.PluginID) IS NULL)
     THEN RAISE(ABORT, 'update on table "ImportSource" violates foreign key. [PluginID in ImportProperties doesnt exist]')
  END;
END;
COMMIT;

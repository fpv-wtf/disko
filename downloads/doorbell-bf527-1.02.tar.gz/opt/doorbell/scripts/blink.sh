#!/bin/sh

echo 1 > /sys/class/gpio/gpio112/value
usleep 50000
echo 0 > /sys/class/gpio/gpio112/value
echo 1 > /sys/class/gpio/gpio113/value
usleep 50000
echo 0 > /sys/class/gpio/gpio113/value
echo 1 > /sys/class/gpio/gpio114/value
usleep 50000
echo 0 > /sys/class/gpio/gpio114/value
echo 1 > /sys/class/gpio/gpio115/value
usleep 50000
echo 0 > /sys/class/gpio/gpio115/value
echo 1 > /sys/class/gpio/gpio116/value
usleep 50000
echo 0 > /sys/class/gpio/gpio116/value
echo 1 > /sys/class/gpio/gpio117/value
usleep 50000
echo 0 > /sys/class/gpio/gpio117/value
echo 1 > /sys/class/gpio/gpio118/value
usleep 50000
echo 0 > /sys/class/gpio/gpio118/value
echo 1 > /sys/class/gpio/gpio119/value
usleep 50000
echo 0 > /sys/class/gpio/gpio119/value

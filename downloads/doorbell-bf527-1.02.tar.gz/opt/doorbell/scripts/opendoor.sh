#!/bin/sh

#beep -l 1000 -f 100
#echo "door is open ..."
cat ./share/buzzer.wav > /dev/dsp &


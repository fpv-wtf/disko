/*
 * main.cpp
 *
 *  Created on: Apr 14, 2009
 *      Author: sxs
 */

#include <mms.h>
#include <mmscore/mmstranslator.h>

int main(int argc, char *argv[]) {


	try {
		mmsInit(MMSINIT_WINDOWS,0,NULL,"./diskorc");
		MMSTranslator trans;

		MMSWindow *window = new MMSRootWindow("default_rootwindow","100%","100%",MMSALIGNMENT_CENTER,MMSW_NONE,NULL);
		MMSLabelWidget *label = new MMSLabelWidget(window,"default_label",NULL);
		string source="WELCOMEMSG";
		label->setText(source);
		window->add(label);
		window->show();
		sleep(2);
		trans.setTargetLang("de");
	} catch (MMSError *err) {
		fprintf(stderr,"%s\n",err->getMessage().c_str());
	}

	while(1)
		sleep(1);
	return 0;
}

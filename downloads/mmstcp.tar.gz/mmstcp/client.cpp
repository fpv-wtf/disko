#include <disko.h>

int main(int argc, char *argv[]) {
	MMSTCPClient *client = new MMSTCPClient("127.0.0.1",11111);
	string retstr;

	client->sendAndReceive("ask iface two", &retstr);

	cout  << "answer was: " << retstr << endl;

	return 0;
}


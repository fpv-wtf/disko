#include <disko.h>

class MyInterface : public MMSServerInterface {
    public:
        MyInterface() : MMSServerInterface("iface1") {};
        ~MyInterface() {};
        bool processRequest(string *request, string *answer);
};

/* is called whever a request is made to the server*/
bool MyInterface::processRequest(string *request, string *answer) {

    cout << "request is: " << *request << endl;
	/* set the string that ist to be sent back */
	if(*request == "ask iface one")
	    answer->append("pong from iface!\n");
	else
		return false;    

	return true;
}



int main(int argc, char *argv[]) {
	MyInterface *iface = new MyInterface();
	
	/* create interface vector - handle multiple request 
	   in parallel (threaded) by adding multiple interface 
	   instaces to the vector */
	std::vector <MMSServerInterface*> interfaces;
	interfaces.push_back(iface);

	 /* start the server */
	MMSTCPServer *server = new MMSTCPServer(interfaces,"127.0.0.1",11111);
	server->start();

	/* suspend the process */
	pause();
	return 0;
}
